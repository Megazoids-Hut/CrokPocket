# QTPY ESP32

- Status:
- Ref:

# Hardware info
- Module: ESP32-???

# Images

![device.jpg](device.jpg)
