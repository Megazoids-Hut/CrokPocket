import os

os.environ["IDF_TARGET"] = "esp32s3"
os.environ["FW_FORMAT"] = "none"
