# ESP32-S3-DevKitC
- Status:
- Ref: https://docs.espressif.com/projects/esp-idf/en/v5.3.1/esp32s3/hw-reference/esp32s3/user-guide-devkitc-1.html

# Hardware info

# Known issues:

# Images
![device.jpg](device.jpg)
