# Retro-ESP32
- Status:
- Ref: https://github.com/retro-esp32/

# Hardware info
- Module: ESP32-WROVER-B

# Images
![device.jpg](device.jpg)
