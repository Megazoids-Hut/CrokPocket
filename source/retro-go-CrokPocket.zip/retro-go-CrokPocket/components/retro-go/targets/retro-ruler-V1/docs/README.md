# Retro-ruler-V1
- Status:
- Ref: https://github.com/raphatex/retro-ruler

# Hardware info
- Module: ESP32-WROVER-B (4/8MB Flash)

# Images
![device.png](device.png)
