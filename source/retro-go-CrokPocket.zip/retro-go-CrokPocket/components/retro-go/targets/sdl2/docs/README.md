# SDL2
- Status: Development only
- Ref: https://wiki.libsdl.org/

SDL2 port is intended for development purposes, it isn't useful to end users.
