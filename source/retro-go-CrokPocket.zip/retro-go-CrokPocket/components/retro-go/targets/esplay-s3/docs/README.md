# Esplay-S3
- Status:
- Ref:

# Hardware
- Module: ESP32-S3

# Images
