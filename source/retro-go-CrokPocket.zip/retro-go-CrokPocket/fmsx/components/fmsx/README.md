In the `src` folder is unmodified fMSX 6.0 by Marat Fayzullin from https://fms.komkon.org/fMSX/.

`msxfix.c` wraps certain functions to allow it to work well within retro-go/esp-idf.
