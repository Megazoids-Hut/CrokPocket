/**
 * This is a placeholder. The implementation is currently in map004.c
 */
