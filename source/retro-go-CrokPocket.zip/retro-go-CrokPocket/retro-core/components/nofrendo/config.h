#define APP_STRING  "Nofrendo"
#define APP_VERSION "3.0"

/* Uncomment to enable debugging messages */
// #define NOFRENDO_DEBUG

/* Uncomment to enable live dissassembler */
// #define NES6502_DISASM

/* Uncomment to save/load a game's SRAM to disk */
// #define USE_SRAM_FILE

/* Uncomment on big-endian machines */
// #define IS_BIG_ENDIAN
