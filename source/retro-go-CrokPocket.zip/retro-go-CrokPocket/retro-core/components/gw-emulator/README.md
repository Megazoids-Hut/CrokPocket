# LCD-Game-Emulator
This is the LCD Game Emulator source code for portable device.

# Version
This is a snapshot of https://github.com/bzhxx/LCD-Game-Emulator/tree/d3ccf35dd4dd92ead8dfa8388860ab2af5ab742e
