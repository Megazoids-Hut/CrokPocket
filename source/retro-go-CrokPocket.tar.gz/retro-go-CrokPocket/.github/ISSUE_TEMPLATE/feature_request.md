---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

## Describe the problem you're trying to solve ##
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

## Describe the solution you have in mind ##
A clear and concise description of what you want to happen.

## Additional context ##
Here you can add screenshots, references, etc
