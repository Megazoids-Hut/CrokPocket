# Gwenesis
This is an optimized Genesis & Megadrive Emulator.
The emulator is able to run at 60fps with sound support on ARM Cortex single core MCU (STM32H7 Cortex-M7 280MHz).
You can find an example of instance for the device Game & Watch (Mario or Zelda):
https://github.com/bzhxx/game-and-watch-retro-go

# Info 
This is a snapshot of https://github.com/bzhxx/gwenesis @ 168e466
