# CrokPocket
- Status: Completed
- Ref: LINK TO BE UPDATED

# Hardware info

- ESP32-S3 N16R8 (16MB flash + 8MB PSRAM)
- Status LED
- USB-C connector



# Images
![device.jpg](device.jpg)
