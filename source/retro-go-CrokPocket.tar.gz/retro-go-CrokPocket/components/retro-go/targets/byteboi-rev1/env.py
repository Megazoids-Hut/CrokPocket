import os

os.environ["IDF_TARGET"] = "esp32"
os.environ["FW_FORMAT"] = "none"
