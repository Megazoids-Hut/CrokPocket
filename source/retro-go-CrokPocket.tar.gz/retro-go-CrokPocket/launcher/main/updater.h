void updater_show_dialog(void);
