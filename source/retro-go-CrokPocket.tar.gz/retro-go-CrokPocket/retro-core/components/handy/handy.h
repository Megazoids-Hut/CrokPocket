#undef INTSET
#undef PS

#include "system.h"
#include "lynxdef.h"
